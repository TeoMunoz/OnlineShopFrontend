<html>
    <head>

        <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Home</title>

		<link rel="stylesheet" type="text/css" href="view/style.css">

		<script src="controller/commands.js"></script>

    </head>
    <body>
        <div class="menu">
            <a href="products.php">Products</a>
            <a href="category.php">Category</a>
            <a href="create-products.php">Create Products</a>
            <a href="create-category.php">Create Category</a>
            <a href="index.php">Logout</a>
        </div>
    </body>
    