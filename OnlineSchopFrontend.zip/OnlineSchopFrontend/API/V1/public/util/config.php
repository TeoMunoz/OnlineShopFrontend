<?php
	//API credentials.
	$api_username = "root";
	$api_password = "sUP3R53CR3T#";

	//Database connection information.
	$db_hostname = "localhost";
	$db_username = "root";
	$db_password = "sUP3R53CR3T#";
	$db_database = "test";
?>